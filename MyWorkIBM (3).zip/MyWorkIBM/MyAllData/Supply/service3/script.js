document.getElementById('product-form').addEventListener('submit', function(e) {
    e.preventDefault();

    // Get form values
    const productid = document.getElementById('product-id').value;
    const productName = document.getElementById('product-name').value;
    const productQuantity = document.getElementById('product-quantity').value;
    const productCost = document.getElementById('product-cost').value;
    const productSupplier = document.getElementById('product-supplier').value;

    // Create new table row
    const tableBody = document.getElementById('product-table-body');
    const newRow = document.createElement('tr');

    // Create table data cells
    const idCell = document.createElement('td');
    idCell.textContent = productid;
    newRow.appendChild(idCell);

    const nameCell = document.createElement('td');
    nameCell.textContent = productName;
    newRow.appendChild(nameCell);

    const quantityCell = document.createElement('td');
    quantityCell.textContent = productQuantity;
    newRow.appendChild(quantityCell);

    const costCell = document.createElement('td');
    costCell.textContent = `Rs ${parseFloat(productCost).toFixed(2)}`;
    newRow.appendChild(costCell);

    const supplierCell = document.createElement('td');
    supplierCell.textContent = productSupplier;
    newRow.appendChild(supplierCell);

    const actionsCell = document.createElement('td');
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', function() {
        tableBody.removeChild(newRow);
    });
    actionsCell.appendChild(deleteButton);
    newRow.appendChild(actionsCell);

    // Add the new row to the table body
    tableBody.appendChild(newRow);

    // Clear form fields
    document.getElementById('product-form').reset();
});
