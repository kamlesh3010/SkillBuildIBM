<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logistics and Production</title>
    <link rel="stylesheet" href="styles.css">

    <script>
      function toggleSection(id) {
    const element = document.getElementById(id);
    if (element.classList.contains('hidden')) {
        element.classList.remove('hidden');
    } else {
        element.classList.add('hidden');
    }
}

    </script>
</head>


<style>
  body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.container {
    width: 80%;
    margin: auto;
    overflow: hidden;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1, h2 {
    color: #333;
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

h2 {
    color: #0056b3;
}

h3 {
    color: #333;
}

p {
    margin: 10px 0;
}

ul {
    list-style: none;
    padding: 0;
}

ul li {
    background: #e9ecef;
    margin: 5px 0;
    padding: 10px;
    border-radius: 5px;
}

ul li strong {
    color: #0056b3;
}

img {
    max-width: 100%;
    height: auto;
    margin: 10px 0;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.toggle-button {
    background: #0056b3;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    margin: 10px 0;
    font-size: 16px;
}

.toggle-button:hover {
    background: #003d80;
}

.hidden {
    display: none;
}

</style>
<body>
    <div class="container">
        <h1>Logistics and Production</h1>
        
        <section id="logistics">
            <h2>Logistics</h2>
            <button class="toggle-button" onclick="toggleSection('logistics-details')">More Details</button>
            <div id="logistics-details" class="hidden">
                <h3>Definition:</h3>
                <p>Logistics involves the planning, implementation, and control of the movement and storage of goods, services, or information within a supply chain and between points of origin and consumption.</p>
                <img src="image/image.png" alt="Logistics Definition Image" class="logistics-image">
                
                <h3>Key Components:</h3>
                <ul>
                    <li><strong>Transportation:</strong> Movement of goods via road, rail, air, or sea.</li>
                    <li><strong>Warehousing:</strong> Storage of goods until they are needed.</li>
                    <li><strong>Inventory Management:</strong> Keeping track of inventory levels, orders, sales, and deliveries.</li>
                    <li><strong>Order Fulfillment:</strong> Process of receiving, processing, and delivering orders to customers.</li>
                    <li><strong>Supply Chain Management:</strong> Coordination of all logistics functions and activities in a supply chain.</li>
                </ul>
                <img src="image/image2.png" alt="Logistics Image" class="logistics-image">
                
                <h3>Types:</h3>
                <ul>
                    <li>
                        <strong>Inbound Logistics:</strong> 
                        <p>Inbound logistics is used to execute strategic organizational tasks for working upstream. Under this inbound logistics, the movement, transportation and storage solutions of various information and product from the suppliers is passed onto the warehouse and then is transferred to the production facilities for further processing & production. Inbound logistics is all about the transportation between the companies and their suppliers.</p>
                        <p>The logistic firms intend to use order-fulfillment systems or automatic ordering for proficiently managing the inbound logistics. And with this integration, you can expect to enhance the successful aspects of your organization. For instance, if you are manufacturing car parts in your factory, you will need to ship them to businesses or recipients such as manufacturers, for implementing them upon the finished products.</p>
                        <p>The job of inbound logistics is to transfer the crude or raw materials to the respective departments or manufacturers for further processing. Large trucks are mostly preferred for transporting these crude raw materials. Logistics companies have wide network and large trucks to safely transport the goods without much cost. It is the first step within the value chain of logistics, for which it is important to seek better process flow, to avoid hampering the remaining processes. Choose the right logistics company for a hassle-free logistics service. Trans Asia Group can help you with setting up your inbound logistics in an efficient manner.</p>
                    </li>
                    <img src="image/image3.png" alt="Logistics Image" class="logistics-image">
                
                    <li>
                        <strong>Outbound Logistics:</strong>
                        <p>Outbound logistics is the movement of products or finished goods from the production centers to the next supply chain link. After that, these products are moved from the warehouse to the consumption point or the customers. Hence, outbound logistics is also known as the process of order fulfillment.</p>
                        <p>All the products that are shipped under outbound logistics are meant for end-users, moving through this process flow. The inbound logistics is used to help the raw materials reach out to the manufacturer, and the processed product is then transported to the end-users through outbound logistics.</p>
                        <p>In simple terms outbound services allow businesses to ship & deliver their specified products from warehouse storage to the customer’s doorstep. There are separate sets of tracking solutions available for the end-users to monitor the movement of their parcel. Extra care should be taken as outbound logistics play a major role in building the reputation of businesses, as customers expect on-time and safe delivery of their goods or products.</p>
                        <p>Hire logistic companies like Trans Asia Group for your businesses as they offer outbound logistics with same-day delivery, depending upon the location. You can trust Trans Asia with the delivery of products within the estimated time.</p>
                    </li>
                </ul>
            </div>
        </section>

        <section id="production">
            <h2>Production</h2>
            <button class="toggle-button" onclick="toggleSection('production-details')">More Details</button>
            <div id="production-details" class="hidden">
                <h3>Definition:</h3>
                <p>Production is the process of creating goods and services from various resources through manufacturing, mining, farming, or other methods.</p>
                
                <h3>Key Components:</h3>
                <ul>
                    <li><strong>Production Planning:</strong> Determining the production schedule, resources required, and timeline.</li>
                    <li><strong>Production Control:</strong> Monitoring and managing production activities to ensure they go according to plan.</li>
                    <li><strong>Quality Control:</strong> Ensuring that the products meet specified standards and customer expectations.</li>
                    <li><strong>Process Improvement:</strong> Continuously improving production processes to increase efficiency and reduce costs.</li>
                </ul>
                
                <h3>Types:</h3>
                <ul>
                    <li><strong>Job Production:</strong> Producing custom or unique products one at a time.</li>
                    <li><strong>Batch Production:</strong> Producing a group of identical products at one time.</li>
                    <li><strong>Mass Production:</strong> Producing large quantities of standardized products, usually on assembly lines.</li>
                    <li><strong>Continuous Production:</strong> Producing products without interruption, typically used for liquids, chemicals, or other commodities.</li>
                </ul>
            </div>
        </section>

        <section id="relationship">
            <h2>Relationship Between Logistics and Production</h2>
            <button class="toggle-button" onclick="toggleSection('relationship-details')">More Details</button>
            <div id="relationship-details" class="hidden">
                <ul>
                    <li><strong>Supply Chain Integration:</strong> Efficient production relies on timely logistics to ensure raw materials are available when needed, and logistics depends on production to provide finished goods for distribution.</li>
                    <li><strong>Just-In-Time (JIT) Production:</strong> A strategy that aligns raw-material orders from suppliers directly with production schedules to reduce inventory costs, requiring highly coordinated logistics.</li>
                    <li><strong>Lean Manufacturing:</strong> Focuses on minimizing waste within manufacturing systems while ensuring product quality, relying heavily on effective logistics to streamline operations.</li>
                </ul>
            </div>
        </section>
    </div>
    <script src="scripts.js"></script>
</body>
</html>
